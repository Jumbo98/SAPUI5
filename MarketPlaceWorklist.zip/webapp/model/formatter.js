sap.ui.define([
	"sap/ui/core/format/DateFormat"
], function(dateFormat) {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		creationInfo: function(dDate, sFullName) {
			var oBundle = this.getModel("i18n").getResourceBundle(),
				sModified = oBundle.getText("tableModifiedByFullName"),
				sDateModified = oBundle.getText("dateModified"),
				sDateAgo = oBundle.getText("dateAgo"),
				sDateDay = oBundle.getText("dateDay"),
				sDateHours = oBundle.getText("dateHours"),
				sDateOn = oBundle.getText("dateOn"),
				sDateMinute = oBundle.getText("dateMinute");

			var oDateFormat = dateFormat.getDateTimeInstance({
				pattern: "EEE, MMM dd, YYYY,"
			}).format(dDate);

			if (dDate && sFullName) {
				var dCurrentDate = new Date(),
					sSecondName = sFullName.slice(sFullName.indexOf(" ") + 1);

				var oneDay = 1000 * 60 * 60 * 24,
					oneHours = 1000 * 60 * 60,
					oneMinute = 1000 * 60,
					diffInTime = dCurrentDate - dDate,
					diffInDays = Math.floor(diffInTime / oneDay),
					diffInHours = Math.floor(diffInTime / oneHours) - diffInDays * 24,
					diffInMinutes = Math.floor(diffInTime / oneMinute) - diffInDays * 24 *
					60 - diffInHours * 60;
				var nDifferenceBetweenDay = diffInDays > 0 ? `${diffInDays}${sDateDay}` : "",
					nDifferenceBetweenHours = diffInHours > 0 ? `${diffInHours}${sDateHours}` : "",
					nDifferenceBetweenMinute = `${diffInMinutes}${sDateMinute}`;
			}

			return `${sModified} ${sSecondName} ${sDateOn} ${oDateFormat} ${sDateModified} ${nDifferenceBetweenDay} ${nDifferenceBetweenHours} ${nDifferenceBetweenMinute} ${sDateAgo}`;
		}

	};

});