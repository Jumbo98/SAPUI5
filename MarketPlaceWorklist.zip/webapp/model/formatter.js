sap.ui.define([
	"sap/ui/core/format/DateFormat"
], function(dateFormat) {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		creationInfo: function(dDate, sFullName) {
			var oBundle = this.getModel("i18n").getResourceBundle(),
				sModified = oBundle.getText("tableModifiedByFullName"),
				sDateModified = oBundle.getText("dateModified"),
				sDateAgo = oBundle.getText("dateAgo"),
				sDateDay = oBundle.getText("dateDay"),
				sDateHours = oBundle.getText("dateHours"),
				sDateOn = oBundle.getText("dateOn"),
				sDateMinute = oBundle.getText("dateMinute");

			var oDateFormat = dateFormat.getDateTimeInstance({
				pattern: "EEE, MMM dd, YYYY,"
			}).format(dDate);

			if (dDate && sFullName) {
				var dCurrentDate = new Date(),
					dCurrentDateHours = dCurrentDate.getHours(),
					dCurrentDateMinutes = dCurrentDate.getMinutes(),

					dDateHours = dDate.getHours(),
					dDateMinutes = dDate.getMinutes(),
					sSecondName = sFullName.slice(sFullName.indexOf(" ") + 1);

				var date1 = new Date(dDate);
				var date2 = new Date(dCurrentDate);
				var oneDay = 1000 * 60 * 60 * 24;
				var diffInTime = date2.getTime() - date1.getTime();
				var diffInDays = Math.floor(diffInTime / oneDay);

				var nDifferenceBetweenDay = diffInDays > 0 ?  `${diffInDays}${sDateDay}` : "" ,

					nDifferenceBetweenHours = dCurrentDateHours > dDateHours ? dCurrentDateMinutes >= dDateMinutes ?
					`${dCurrentDateHours - dDateHours}${sDateHours}` : `${dCurrentDateHours - dDateHours - 1}${sDateHours}` : dCurrentDateMinutes >
					dDateMinutes ? `${Math.abs(dDateHours - 24)+dCurrentDateHours}${sDateHours}` : dCurrentDateMinutes - dDateMinutes === 0 ? `"1"${sDateHours}`:
					`${Math.abs(dDateHours - 23)+dCurrentDateHours}${sDateHours}`, 

					nDifferenceBetweenMinute = dCurrentDateMinutes > dDateMinutes ? `${dCurrentDateMinutes - dDateMinutes}${sDateMinute}` : dCurrentDateMinutes - dDateMinutes === 0 ? `"0"${sDateMinute}` :
					`${Math.abs(dDateMinutes - 60)+dCurrentDateMinutes}${sDateMinute}`;
			}

			return `${sModified} ${sSecondName} ${sDateOn} ${oDateFormat} ${sDateModified} ${nDifferenceBetweenDay} ${nDifferenceBetweenHours} ${nDifferenceBetweenMinute} ${sDateAgo}`;
		}

	};

});