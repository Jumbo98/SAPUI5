/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zjblessons/MarketPlaceWorklist/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zjblessons/MarketPlaceWorklist/test/integration/pages/Worklist",
	"zjblessons/MarketPlaceWorklist/test/integration/pages/Object",
	"zjblessons/MarketPlaceWorklist/test/integration/pages/NotFound",
	"zjblessons/MarketPlaceWorklist/test/integration/pages/Browser",
	"zjblessons/MarketPlaceWorklist/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zjblessons.MarketPlaceWorklist.view."
	});

	sap.ui.require([
		"zjblessons/MarketPlaceWorklist/test/integration/WorklistJourney",
		"zjblessons/MarketPlaceWorklist/test/integration/ObjectJourney",
		"zjblessons/MarketPlaceWorklist/test/integration/NavigationJourney",
		"zjblessons/MarketPlaceWorklist/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});