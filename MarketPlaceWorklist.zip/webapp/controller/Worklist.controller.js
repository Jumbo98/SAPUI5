/*global location history */
sap.ui.define([
	"zjblessons/MarketPlaceWorklist/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"zjblessons/MarketPlaceWorklist/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator, MessageToast) {
	"use strict";

	return BaseController.extend("zjblessons.MarketPlaceWorklist.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			// keeps the search state
			this._aTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				resetChange: []
			});
			this.setModel(oViewModel, "worklistView");

			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);

		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		onPressButtonHello: function() {
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			var sMsg = oBundle.getText("helloMsg");
			// show message
			MessageToast.show(sMsg);
		},

		onPressButtonDelete: function(oEvent) {
			var sErrorMassage = this.getView().getModel("i18n").getResourceBundle().getText("errorMassage");
			if (oEvent.getParameter("listItem").getBindingContext().getProperty("CreatedBy") === "D1B1000033") {
				var sPath = oEvent.getParameter("listItem").getBindingContext().getPath();
				this.getModel().remove(sPath);
			} else {
				sap.m.MessageBox.error(sErrorMassage, {
					styleClass: "sapUiSizeCompact"
				});
			}

		},

		onPressButtonCreate: function() {
			if (!this.oDialogCreate) {
				var oBundle = this.getView().getModel("i18n").getResourceBundle(),

					sTitle = oBundle.getText("createTitle"),
					sMaterialText = oBundle.getText("tableNameColumnTitle"),
					sGroupId = oBundle.getText("tableGroupId"),
					sSubGroupId = oBundle.getText("tableSubGroupId"),
					sBtnCreate = oBundle.getText("btnCreate"),
					sBtnClose = oBundle.getText("btnClose"),
					sLanguage = oBundle.getText("language"),
					sVersion = oBundle.getText("version");

				this.oDialogCreate = new sap.m.Dialog({
					title: sTitle,
					type: "Message",
					contentWidth: "24em",
					content: [

						new sap.m.Label({
							text: sMaterialText,
							lableFor: "MaterialTextCreate"
						}),
						new sap.m.Input("MaterialTextCreate", {
							width: "100%",
							maxLength: 20,
							liveChange: function() {
								this._liveChageStateCreateButton();
							}.bind(this)
						}),

						new sap.m.Label({
							text: sGroupId,
							lableFor: "GroupIdCreate"
						}),
						new sap.m.Input("GroupIdCreate", {
							width: "100%",
							maxLength: 5,
							liveChange: function() {
								this._liveChageStateCreateButton();
							}.bind(this)
						}),

						new sap.m.Label({
							text: sSubGroupId,
							lableFor: "SubGroupIdCreate"
						}),
						new sap.m.Input("SubGroupIdCreate", {
							width: "100%",
							maxLength: 5,
							liveChange: function() {
								this._liveChageStateCreateButton();
							}.bind(this)
						}),

						new sap.m.Label({
							text: sVersion,
							lableFor: "VersionCreate"
						}),
						new sap.m.Input("VersionCreate", {
							width: "100%",
							blocked: true,
							value: "A"
						}),

						new sap.m.Label({
							text: sLanguage,
							lableFor: "Language"
						}),
						new sap.m.Switch("Language", {
							state: true,
							customTextOn: "RU",
							customTextOff: "EN",
							width: "100px"
						})
					],
					beginButton: new sap.m.Button({
						type: "Emphasized",
						text: sBtnCreate,
						enabled: false,
						press: function() {
							this._createMaterial();
							this.oDialogCreate.close(this._clearDialogInput());
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: sBtnClose,
						press: function() {
							this.oDialogCreate.close(this._clearDialogInput());
						}.bind(this)
					})
				}).addStyleClass("sapUiSizeCompact");

				this.getView().addDependent(this.oDialogCreate);
			}
			this.oDialogCreate.open();
		},

		_clearDialogInput: function() {
			if (this.oDialogCreate) {
				this.oDialogCreate.getContent()[1].setValue("");
				this.oDialogCreate.getContent()[3].setValue("");
				this.oDialogCreate.getContent()[5].setValue("");
			} else {
				this.oDialogEdit.getContent()[1].setValue("");
				this.oDialogEdit.getContent()[3].setValue("");
				this.oDialogEdit.getContent()[5].setValue("");
			}
		},

		_liveChageStateCreateButton: function() {
			if (this.oDialogCreate) {
				if (this.oDialogCreate.getContent()[1].getValue().split(" ").join("").length > 0 && this.oDialogCreate.getContent()[3].getValue()
					.split(" ").join("").length > 0 && this.oDialogCreate.getContent()[5].getValue().split(" ").join("").length > 0) {
					this.oDialogCreate.getAggregation("beginButton").setEnabled(true);
				} else {
					this.oDialogCreate.getAggregation("beginButton").setEnabled(false);
				}
			}
		},

		_createMaterial: function(oEvent) {
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			var sSuccessCreate = oBundle.getText("successCreate");
			var sErrorCreate = oBundle.getText("errorCreate");

			var oEntry = {
				MaterialID: '',
				MaterialText: this.oDialogCreate.getContent()[1].getValue(),
				Language: this.oDialogCreate.getContent()[9].getState() ? "RU" : "EN",
				GroupID: this.oDialogCreate.getContent()[3].getValue(),
				SubGroupID: this.oDialogCreate.getContent()[5].getValue(),
				Version: this.oDialogCreate.getContent()[7].getValue()
			};
			this.getModel().create("/zjblessons_base_Materials", oEntry, {
				success: function() {
					MessageToast.show(sSuccessCreate);
				},
				error: function() {
					MessageToast.show(sErrorCreate);
				}
			});
		},

		onPressButtonEdit: function(oEvent) {
			this._getElementalData(oEvent);

			if (!this.oDialogEdit) {

				var oBundle = this.getView().getModel("i18n").getResourceBundle(),

					sTitleEdit = oBundle.getText("editTitle"),
					sMaterialText = oBundle.getText("tableNameColumnTitle"),
					sGroupId = oBundle.getText("tableGroupId"),
					sSubGroupId = oBundle.getText("tableSubGroupId"),
					sBtnOk = oBundle.getText("btnEdit"),
					sBtnClose = oBundle.getText("btnClose");

				this.oDialogEdit = new sap.m.Dialog({
					title: sTitleEdit,
					type: "Message",
					contentWidth: "24em",
					content: [

						new sap.m.Label({
							text: sMaterialText,
							lableFor: "MaterialTextEdit"
						}),
						new sap.m.Input("MaterialTextEdit", {
							width: "100%",
							maxLength: 20,
							value: "{MaterialText}"
						}),

						new sap.m.Label({
							text: sGroupId,
							lableFor: "GroupIdEdit"
						}),
						new sap.m.Input("GroupIdEdit", {
							width: "100%",
							maxLength: 5,
							value: "{GroupID}"
						}),

						new sap.m.Label({
							text: sSubGroupId,
							lableFor: "SubGroupIdEdit"
						}),
						new sap.m.Input("SubGroupIdEdit", {
							width: "100%",
							maxLength: 5,
							value: "{SubGroupID}"
						})
					],
					buttons: [
						new sap.m.Button({
							icon: "sap-icon://reset",
							type: "Ghost",
							enabled: false,
							press: function() {
								var oResetObj = this.getModel("worklistView").getProperty("/resetChange");
								this.oDialogEdit.getContent()[1].setValue(oResetObj.MaterialText);
								this.oDialogEdit.getContent()[3].setValue(oResetObj.GroupID);
								this.oDialogEdit.getContent()[5].setValue(oResetObj.SubGroupID);
							}.bind(this)
						}),

						new sap.m.Button({
							type: "Emphasized",
							text: sBtnOk,
							press: function() {
								this.oDialogEdit.close();
								this.oDialogEdit.getAggregation("buttons")[0].setProperty("enabled", false);
							}.bind(this)
						})

						// new sap.m.Button({
						// 	text: sBtnClose,
						// 	press: function() {
						// 		this.oDialogEdit.close();
						// 	}.bind(this)
						// })                          Она не нужна тут =(
					]
				}).addStyleClass("sapUiSizeCompact");

				this.getView().addDependent(this.oDialogEdit);
			}
			this.oDialogEdit.open();
			this.oDialogEdit.setBindingContext(oEvent.getSource().getBindingContext());
		},

		_editMaterial: function(oEvent) {
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			var sSuccessEdit = oBundle.getText("successEdit");
			var sErrorEdit = oBundle.getText("errorEdit");

			var sPath = this.oDialogEdit.getBindingContext().getPath();
			this.getModel().update(sPath, {
				MaterialText: this.oDialogEdit.getContent()[1].getValue(),
				GroupID: this.oDialogEdit.getContent()[3].getValue(),
				SubGroupID: this.oDialogEdit.getContent()[5].getValue()
			}, {
				success: function(e) {
					MessageToast.show(sSuccessEdit);
				},
				error: function(e) {
					MessageToast.show(sErrorEdit);
				}
			});
		},

		_getElementalData: function(oEvent) {
			var oBundle = this.getView().getModel("i18n").getResourceBundle().getText("errorCreate");

			var sPath = oEvent.getSource().getBindingContext().getPath();
			this.getModel().read(sPath, {
				success: function(oData) {
					this.getModel("worklistView").setProperty("/resetChange", Object.assign({}, oData));
					this.oDialogEdit.getAggregation("buttons")[0].setProperty("enabled", true);
				}.bind(this),
				error: function() {
					sap.m.MessageToast.show(oBundle);
				}
			});
		},

		onPressButtonSubmitChanges: function() {
			this.getModel().submitChanges();
		},

		onPressButtonRefresh: function() {
			this.getModel().refresh();
		},

		onPressButtonReset: function() {
			this.getModel().resetChanges();
		},

		onPressButtonItemReset: function(oEvent) {
			var sPath = oEvent.getSource().getBindingContext().getPath();
			this.getModel().resetChanges(sPath);
			this.getModel("worklistView").setProperty("/resetMode", true);
		},

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser historz
		 * @public
		 */
		onNavBack: function() {
			history.go(-1);
		},

		onSearch: function(oEvent) {
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			var sTitle = oBundle.getText("createTitle");
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("MaterialText", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("MaterialID")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
		 * @private
		 */
		_applySearch: function(aTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(aTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});