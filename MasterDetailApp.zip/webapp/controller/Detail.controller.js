sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/m/MessageToast",
	"sap/ui/comp/smarttable/SmartTable",
	"sap/ui/comp/smartfilterbar/SmartFilterBar",
	"sap/m/OverflowToolbar",
	"sap/m/ToolbarSpacer",
	"sap/m/OverflowToolbarButton",
	"sap/m/OverflowToolbarToggleButton",
	"sap/m/ObjectStatus",
	"sap/m/Button",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox"

], function(BaseController, JSONModel, formatter, MessageToast, SmartTable, SmartFilterBar, OverflowToolbar, ToolbarSpacer,
	OverflowToolbarButton, OverflowToolbarToggleButton, ObjectStatus, Button, Filter, FilterOperator, Fragment, MessageBox) {
	"use strict";

	return BaseController.extend("jetcourses.MasterDetailApp.controller.Detail", {

		formatter: formatter,

		_mFilters: {
			activeVersion: new Filter("Version", FilterOperator.NE, "D"),
			deactiveVersion: new Filter("Version", FilterOperator.EQ, "D")
		},

		_oViewModel: new JSONModel({
			button: {
				visible: {
					Create: true,
					Update: true,
					DeactivateDelete: true,
					Restore: true,
					Refresh: true,
					Copy: true,
					ChangeSelectionMode: true,
					ChangeVersionMode: true
				},
				pressed: {
					ChangeSelectionMode: false,
					ChangeVersionMode: false
				}
			},
			table: {
				selectionMode: "Single",
				selectedItemsCount: 0
			},
			dialog: {
				title: "",
				inputValue: "",
				mode: "",
				updatePath: "",
				label: "",
				nameField: "",
				idField: ""
			}
		}),

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(this._oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function() {
			var oViewModel = this.getModel("detailView");

			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {

			var sEntity = oEvent.getParameter("arguments").entity;
			this.getModel().metadataLoaded().then(function() {
				this.byId("thDetail").setText(this.getModel("i18n").getResourceBundle().getText("t" + sEntity));
				this._loadTable(sEntity);
				this.getModel("detailView").setProperty("/dialog/idField", this._oSmartTable.getEntitySet().slice(16, -1) + "ID");
				this.getModel("detailView").setProperty("/dialog/nameField", this._oSmartTable.getEntitySet().slice(16, -1) + "Text");
			}.bind(this));
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */

		_loadTable: function(sEntity) {

			this._oSmartFilterBar = new SmartFilterBar({
				id: "sf" + sEntity,
				entitySet: "zjblessons_base_" + sEntity,
				liveMode: true,
				enableBasicSearch: false,
				useToolbar: true
			});

			this._oSmartTable = new SmartTable({
				entitySet: "zjblessons_base_" + sEntity,
				editable: false,
				smartFilterId: "sf" + sEntity,
				tableType: "Table",
				useExportToExcel: true,
				editTogglable: false,
				useVariantManagement: false,
				useTablePersonalisation: true,
				showVariantManagement: true,
				header: " ",
				showRowCount: true,
				enableAutoBinding: true,
				showFullScreenButton: true,
				visible: true,
				beforeRebindTable: this._onBeforeRebindTable.bind(this),
				customToolbar: new OverflowToolbar({
					design: "Transparent",
					content: [new OverflowToolbarToggleButton({
							text: "{i18n>ttChangeSelectionMode}",
							tooltip: "{i18n>ttChangeSelectionMode}",
							type: "Default",
							icon: "{i18n>iChangeSelectionMode}",
							visible: "{detailView>/button/visible/ChangeSelectionMode}",
							pressed: "{detailView>/button/pressed/ChangeSelectionMode}",
							press: this.onPressChangeSelectionMode.bind(this)
						}),
						// new Button({
						// 	// text:"{i18n>infSelectedItems} {detailView>/table/selectedItemsCount}",
						// 	tooltip:"",
						// 	type:"Default",
						// 	enabled: true,
						// 	iconFirst: false
						// 	// visible:"{=((${detailView>/table/selectedIdCount} > 0) && ())}",
						// }),
						new OverflowToolbarToggleButton({
							text: "{i18n>ttDeactivateMode}",
							tooltip: "{i18n>ttDeactivateMode}",
							type: "Default",
							icon: "{i18n>iDeactivateMode}",
							visible: "{detailView>/button/visible/ChangeVersionMode}",
							pressed: "{detailView>/button/pressed/ChangeVersionMode}",
							press: this.onPressToggleDeactivateMode.bind(this)
						}),
						new ObjectStatus({
							// text:"{i18n>infDeactivateModeOn}",
							inverted: true,
							state: "Warning",
							visible: "{detailView>/button/visible/ChangeSelectionMode}"
						}),
						new ToolbarSpacer(),
						new OverflowToolbarButton({
							text: "{i18n>ttCreate}",
							tooltip: "{i18n>ttCreate}",
							type: "Default",
							icon: "{i18n>iCreate}",
							visible: "{detailView>/button/visible/Create}",
							enabled: "{= !${detailView>/button/pressed/ChangeVersionMode} }",
							press: this.onPressCreateMode.bind(this)
						}),
						new OverflowToolbarButton({
							text: "{i18n>ttCopy}",
							tooltip: "{i18n>ttCopy}",
							type: "Default",
							icon: "{i18n>iCopy}",
							visible: "{detailView>/button/visible/Copy}",
							enabled: "{= ${detailView>/table/selectedItemsCount} === 1 && !${detailView>/button/pressed/ChangeVersionMode}}"
								// press: this.onPressCopyMode.bind(this)
						}),

						new OverflowToolbarButton({
							text: "{i18n>ttRefresh}",
							tooltip: "{i18n>ttRefresh}",
							type: "Default",
							icon: "{i18n>iRefresh}",
							visible: "{detailView>/button/visible/Refresh}",
							press: this.onPressRefreshMode.bind(this)
						}),
						new OverflowToolbarButton({
							text: "{= ${detailView>/button/pressed/ChangeVersionMode} ? ${i18n>ttDelete} :  ${i18n>ttDeactivate}}",
							tooltip: "{= ${detailView>/button/pressed/ChangeVersionMode} ? ${i18n>ttDelete} :  ${i18n>ttDeactivate}}",
							type: "Default",
							icon: "{= ${detailView>/button/pressed/ChangeVersionMode} ? ${i18n>iDelete} :  ${i18n>iDeactivate}}",
							visible: "{detailView>/button/visible/DeactivateDelete}",
							enabled: "{= ${detailView>/table/selectedItemsCount} > 0 }",
							press: this.onPressDeactivateDeleteMode.bind(this)
						}),
						new OverflowToolbarButton({
							text: "{i18n>ttRestore}",
							tooltip: "{i18n>ttRestore}",
							type: "Default",
							icon: "{i18n>iRestore}",
							visible: "{detailView>/button/visible/Restore}",
							enabled: "{= ${detailView>/table/selectedItemsCount} > 0 && ${detailView>/button/pressed/ChangeVersionMode}}",
							press: this.onPressRestoreMode.bind(this)
						})
					]
				})
			});

			this._oTable = this._oSmartTable.getTable();
			this._oTable.bindProperty("selectionMode", {
				path: "detailView>/table/selectionMode"
			});
			this._oSmartTable.setHeader(this.getResourceBundle().getText("tableHeader"));
			this._oTable.setSelectionMode("Single");
			this._oTable.setSelectionBehavior("Row");
			this._oTable.attachRowSelectionChange(this.onSelectionChange.bind(this));

			this.getModel("detailView").setProperty("/table/selectedItemsCount", 0);
			this.getModel("detailView").setProperty("/table/selectionMode", "Single");
			this.getModel("detailView").setProperty("/button/pressed/ChangeSelectionMode", false);
			this.getModel("detailView").setProperty("/button/pressed/ChangeVersionMode", false);

			var oRowActionTemplate = new sap.ui.table.RowAction({
				items: [
					new sap.ui.table.RowActionItem({
						icon: "{i18n>iEdit}",
						type: "Custom",
						text: "{i18n>ttEdit}",
						// press: this.onUpdatePress.bind(this),
						visible: "{= ${detailView>/button/visible/Update} && !${detailView>/button/pressed/ChangeVersionMode} }"
					})
				]
			});

			this._oTable.setRowActionTemplate(oRowActionTemplate);
			this._oTable.setRowActionCount(1);

			this.getView().byId("page").setContent(this._oSmartTable);

			this.getView().byId("page").destroyHeaderContent();
			this.getView().byId("page").addHeaderContent(this._oSmartFilterBar);
		},

		onSelectionChange: function() {
			this.getModel("detailView").setProperty("/table/selectedItemsCount", this._oTable.getSelectedIndices().length);

		},

		onPressChangeSelectionMode: function(oEvent) {
			this.getModel("detailView").setProperty("/table/selectionMode", oEvent.getParameter("pressed") ? "Multi" : "Single");
		},
		onPressToggleDeactivateMode: function(oEvent) {
			this._oSmartTable.rebindTable();
		},
		onPressRefreshMode: function(oEvent) {
			this._oSmartTable.rebindTable(true);
		},
		onPressCreateMode: function() {
			this._oDialogInputValue();
			Fragment.load({
				id: "valueContent",
				name: "jetcourses.MasterDetailApp.view.CreateDialog",
				controller: this
			}).then(oDialog => {
				if (this._oSmartTable.getEntitySet() === "zjblessons_base_Groups") {
					var oContext = this.getModel().createEntry("/" + this._oSmartTable.getEntitySet(), {
						properties: {
							GroupID: "",
							GroupText: this.getModel("detailView").getProperty("/dialog/inputValue"),
							Version: "A",
							Language: "EN"
						}
					});
				} else {
					if (this._oSmartTable.getEntitySet() === "zjblessons_base_SubGroups") {
						var oContext = this.getModel().createEntry("/" + this._oSmartTable.getEntitySet(), {
							properties: {
								SubGroupID: "",
								SubGroupText: this.getModel("detailView").getProperty("/dialog/inputValue"),
								Version: "A",
								Language: "EN"
							}
						});
					} else {
						if (this._oSmartTable.getEntitySet() === "zjblessons_base_Plants") {
							var oContext = this.getModel().createEntry("/" + this._oSmartTable.getEntitySet(), {
								properties: {
									PlantID: "",
									PlantText: this.getModel("detailView").getProperty("/dialog/inputValue"),
									Version: "A",
									Language: "EN"
								}
							});
						} else {
							if (this._oSmartTable.getEntitySet() === "zjblessons_base_Regions") {
								var oContext = this.getModel().createEntry("/" + this._oSmartTable.getEntitySet(), {
									properties: {
										RegionID: "",
										RegionText: this.getModel("detailView").getProperty("/dialog/inputValue"),
										Version: "A",
										Language: "EN"
									}
								});
							}
						}
					}
				}
				this.getView().addDependent(oDialog);
				oDialog.setBindingContext(oContext);
				oDialog.open();
				this._oDialog = oDialog;
			});
		},

		onPressCancel: function(oEvent) {
			this.getModel().resetChanges(),
				this._oDialog.destroy();
			this._oDialog = null;

		},
		onPressCreate: function(oEvent) {
			this.getModel().setProperty(oEvent.getSource().getBindingContext().getPath() + "/SubGroupText", sap.ui.core.Fragment.byId(
				"valueContent", "value").getValue());
			this.getModel().submitChanges({
					success: function() {
						MessageToast.show(this.getModel("i18n").getResourceBundle().getText("msgSuccessCreated"));
					}.bind(this)
				}),
				this._oDialog.destroy();
		},

		onPressRestoreMode: function(oEvent) {
			var aContext = this._oTable.getSelectedIndices().map(item => this._oTable.getContextByIndex(item));
			MessageBox.confirm(this.getResourceBundle().getText("msgRestore"), {
				onClose: function(oAction) {
					if (oAction === MessageBox.Action.OK) {
						aContext.forEach(item => this.getModel().setProperty(item.getPath() + "/Version", "A"));
						this.getModel().submitChanges({
							success: function() {
								MessageToast.show(this.getResourceBundle().getText("msgSuccessRestore"));
							}.bind(this)
						});
					}
				}.bind(this)
			});
		},
		onPressDeactivateDeleteMode: function(oEvent) {
			var aContext = this._oTable.getSelectedIndices().map(item => this._oTable.getContextByIndex(item));
			if (this.getModel("detailView").getProperty("/button/pressed/ChangeVersionMode")) {
				MessageBox.confirm(this.getResourceBundle().getText("msgDelete"), {
					onClose: function(oAction) {
						if (oAction === MessageBox.Action.OK) {
							aContext.forEach(item => {
								this.getModel().remove(item.getPath(), {
									success: function() {
										MessageToast.show(this.getResourceBundle().getText("msgSuccessDelete"));
									}.bind(this)
								});
							});
						}
					}.bind(this)
				});
			} else {
				MessageBox.confirm(this.getResourceBundle().getText("msgDeactivate"), {
					onClose: function(oAction) {
						if (oAction === MessageBox.Action.OK) {
							aContext.forEach(item => this.getModel().setProperty(item.getPath() + "/Version", "D"));
							this.getModel().submitChanges({
								success: function() {
									MessageToast.show(this.getResourceBundle().getText("msgSuccessDeactivate"));
								}.bind(this)
							});
						}
					}.bind(this)
				});
			}
		},

		_oDialogInputValue: function() {
			if (this._oSmartTable.getEntitySet() === "zjblessons_base_Groups") {
				this.getModel("detailView").setProperty("/dialog/title", "{GroupText}")
			} else
			if (this._oSmartTable.getEntitySet() === "zjblessons_base_SubGroups") {
				this.getModel("detailView").setProperty("/dialog/title", "{SubGroupText}")
			} else
			if (this._oSmartTable.getEntitySet() === "zjblessons_base_Plants") {
				this.getModel("detailView").setProperty("/dialog/title", "{PlantText}")
			} else
			if (this._oSmartTable.getEntitySet() === "zjblessons_base_Regions") {
				this.getModel("detailView").setProperty("/dialog/title", "{RegionText}")
			}

		},

		_onBeforeRebindTable: function(oEvent) {

			if (oEvent) {
				var sFilterKey = this.getModel("detailView").getProperty("/button/pressed/ChangeVersionMode") ? "deactiveVersion" :
					"activeVersion",
					oFilter = this._mFilters[sFilterKey];
				oEvent.getParameter("bindingParams").filters.push(oFilter);
			}
		},

		_onMetadataLoaded: function() {

			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			oViewModel.setProperty("/delay", 0);

			oViewModel.setProperty("/busy", true);

			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		}

	});

});